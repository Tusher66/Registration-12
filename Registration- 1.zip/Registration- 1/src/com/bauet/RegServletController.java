package com.bauet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RegServletController
 */
@WebServlet("/RegServletController")
public class RegServletController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");  
        PrintWriter out=response.getWriter();
		String userName = request.getParameter("username");
		String password = request.getParameter("password");
		String firstName = request.getParameter("firstname");
		String lastName = request.getParameter("lastname");
		String email = request.getParameter("email");
		
        ProjectRelFun pr=new ProjectRelFun();
        int i=0;
        
        // For Insert Function
        if(userName !=null && password !=null) {
        i=pr.insert(userName,password,firstName,lastName,email);
        	
        if(i>0){  
	            RequestDispatcher rd=request.getRequestDispatcher("view.jsp");  
	            rd.forward(request, response);  
	        }  
	        else{  
	            RequestDispatcher rd=request.getRequestDispatcher("/index.jsp");  
	            rd.forward(request, response);  
	        } 
        }
        
        // For Delete Function
        String dltName=request.getParameter("dltName");
        i=0;
        if(dltName!=null) {
        i=pr.deleteData(dltName);
        if(i>0){  
            RequestDispatcher rd=request.getRequestDispatcher("view.jsp");  
            rd.forward(request, response);  
        }  
        else{  
            RequestDispatcher rd=request.getRequestDispatcher("index.jsp");  
            rd.forward(request, response);  
        }
	}
        // For Update Function
        String UpdateUserName=request.getParameter("UpdateUserName");
        i=0;
        if(UpdateUserName!=null) {
        i=pr.UpdateData(UpdateUserName,password,firstName,lastName,email);
        if(i>0){  
            RequestDispatcher rd=request.getRequestDispatcher("view.jsp");  
            rd.forward(request, response);  
        }  
        else{  
            RequestDispatcher rd=request.getRequestDispatcher("update.jsp");  
            rd.forward(request, response);  
            }
        }
	}

}
