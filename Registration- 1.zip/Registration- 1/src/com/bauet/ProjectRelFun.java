package com.bauet;

import java.sql.Connection;
import java.sql.Statement;

public class ProjectRelFun {
	
	public int insert(String userName, String password, String firstName, String lastName, String email) {
		// TODO Auto-generated method stub
		int i=0;
		try {
    		Connection con = DBConnection.getMySqlConnection();
    		Statement stmt = con.createStatement();
    		stmt.executeUpdate("use RegServlet");
    		i=stmt.executeUpdate("insert into servdb values('" + userName + "','" + password + "','" + firstName + "','" + lastName + "','" + email +"') ");  		 
    	} catch (Exception e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    	} 		
		return i;
	}
	
	public int deleteData(String dltname) {
		int i=0;
		try {
    		Connection con = DBConnection.getMySqlConnection();
    		Statement stmt = con.createStatement();
    		stmt.executeUpdate("use RegServlet");    		
    		i=stmt.executeUpdate("delete from servdb where name='"+dltname+"'");
    	} catch (Exception e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    	} 
		return i;		
	}
	
	public int UpdateData(String UpdateUserName, String password, String firstName, String lastName, String email) {
		int i=0;
		try {
    		Connection con = DBConnection.getMySqlConnection();
    		Statement stmt = con.createStatement();
    		stmt.executeUpdate("use RegServlet");
    		i=stmt.executeUpdate("update servdb set name='"+UpdateUserName +"', password='"+password +"', firstName='"+firstName+"',lastName='"+lastName+"', email='"+email+"' where name='"+UpdateUserName+"' ");
    	} catch (Exception e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    	} 
		
		return i;
		
	}


}
