package com.bauet;
import java.sql.*;

public class RegBean {

	private String uname,password,fname,lname,email;  
	  
	public String getName() {  
	    return uname;  
	}  
	public void setName(String name) {  
	    this.uname = name;  
	}  


	public String getPassword() {  
	    return password;  
	}  
	public void setPassword(String password) {  
	    this.password = password;  
	}  

	public void setfname(String fname) {  
	    this.fname = fname;  
	} 

	public String getfname() {  
	    return fname;  
	} 
	
	public void setlname(String lname) {  
	    this.fname = lname;  
	} 

	public String getlname() {  
	    return fname;  
	}
	
	public void setemail(String email) {  
	    this.email = email;  
	} 

	public String getemail() {  
	    return email;  
	}
	
	public boolean validate(){  
	    if(password.equals("admin")){  
	        return true;  
	    }  
	    else{  
	        return false;  
	    }  
	}   
	
	
	
	
	}  